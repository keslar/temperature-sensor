                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2209964
Adafruit Feather Box Enclosure by adafruit is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

YouTube: https://www.youtube.com/watch?v=jy7a-z19UEQ

***NEW UPDATE*** April 8, 2016 – Added new parts for Adafruit 2.4" TFT Feather Wing

This is our 3D printed case for the Adafruit Feather. It’s for anyone looking to put their project in a box. It’s a multipurpose enclosure, so you can use it for a number of different projects. It’s designed to house different battery sizes, so it’s nice and portable. The enclosure itself is made up of three different pieces that all snap fit together. Each part has different versions, so you can make it better fit your project and there’s no wrong way to configured it.

Full Tutorial: https://learn.adafruit.com/3d-printed-case-for-adafruit-feather/overview